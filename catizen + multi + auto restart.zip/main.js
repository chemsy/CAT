import a from "react";
import { render as b } from "ink";
import c from "./components/mainMenuComponent.js";
import d from "./components/formComponent.js";
import e from "./bot/index.js";
import f from "chalk";
import { createSessionDirectory as g, deleteFile as h, getAllFilesFromFolder as i, getSessionDirectory as j, getUserFromUrl as k, readJsonFile as l, runtimeServer as m, writeToFile as n } from "./bot/helper.js";
import o from "./components/startBotComponent.js";
import { exec } from "child_process";

const p = ".catizen-session";
g(p);

async function q(d) {
  return new Promise(e => {
    let f;
    const { waitUntilExit: g } = b(a.createElement(c, {
      banner: d,
      onChange: a => {
        f = a;
        e(f);
      }
    }));
    g();
  });
}

async function r(c, d) {
  return new Promise(e => {
    let f;
    const { waitUntilExit: g } = b(a.createElement(o, {
      accounts: c,
      banner: d,
      onChange: a => {
        f = a;
        e(f);
      }
    }));
    g();
  });
}

async function s(c, e) {
  return new Promise(f => {
    let g;
    const { waitUntilExit: h } = b(a.createElement(d, {
      name: c,
      banner: e,
      onChange: a => {
        g = a;
        f(g);
      }
    }));
    h();
  });
}

(async () => {
  let a = await m();
  if (a.status === "exit") {
    process.stdout.write(a.baner);
    process.exit();
  }

  let b = 0;
  while (a.status === "reconnecting") {
    b++;
    process.stdout.write("c");
    process.stdout.write(a.baner);
    console.log(f.yellowBright("Reconnecting ") + f.whiteBright("•".repeat(b)));
    if (b > 4) {
      b = 0;
    }
    a = await m();
    await new Promise(a => setTimeout(a, 5000));
  }
  process.stdout.write(a.baner);
  process.stdout.write("c");

  // Check for --play, --minutes, and --add arguments
  const args = process.argv.slice(2);
  let minutes = 0;
  if (args.includes("--play")) {
    b = "1";
    const minutesIndex = args.indexOf("--minutes");
    if (minutesIndex !== -1 && args[minutesIndex + 1]) {
      minutes = parseInt(args[minutesIndex + 1], 10);
    }
  }

  if (minutes > 0) {
    setInterval(() => {
      console.log(f.greenBright(`Restarting script after ${minutes} minutes...`));
      exec(`node ${process.argv[1]}`, (error, stdout, stderr) => {
        if (error) {
          console.error(`Error restarting script: ${error}`);
          return;
        }
        console.log(stdout);
        console.error(stderr);
      });
    }, minutes * 60 * 1000); // Convert minutes to milliseconds
  }

  if (args.includes("--add")) {
    const b = await s("Enter your init_data", a.baner);
    console.log("Init data input:", b); // Debug log
    let c;
    try {
      c = k(b);
    } catch (b) {
      await s(f.yellowBright("WTF with your input, Check your input moron!") + "\n" + f.blackBright("Press Enter To Back"), a.baner);
      process.exit(1);
    }
    const d = new e("", b);
    const g = await d.login();
    if ("code" in g) {
      if (g.code === 106) {
        await s(f.redBright("Catizen on Maintenance") + "\n" + f.blackBright("Press Enter To Back"), a.baner);
      }
      if (g.code === 2) {
        await s(f.redBright("Invalid Credentials, Please Recapture Credentials") + "\n" + f.blackBright("Press Enter To Back"), a.baner);
      }
    } else {
      try {
        n(j(p) + "/" + c.username + ".json", JSON.stringify({
          username: c.username,
          access_token: "",
          init_data: b
        }));
        await s(f.greenBright("Success To Add Login") + "\n" + f.blackBright("Press Enter To Back"), a.baner);
      } catch (b) {
        await s(f.redBright("Something went wrong") + "\n" + f.blackBright("Press Enter To Back"), a.baner);
        process.exit(1);
      }
    }
    process.exit(0);
  }

  while (true) {
    if (!args.includes("--play")) {
      const b = await q(a.baner);
      console.log("Menu selection:", b); // Debug log
    }
    if (b === "exit") {
      process.exit();
    }
    if (b === "1") {
      var c = i(p);
      let b = [];
      for (let a = 0; a < c.length; a++) {
        let e = c[a];
        if (e) {
          var d = l(e);
          b.push(d);
        }
      }
      if (c.length < 1) {
        await s(f.yellowBright("Account is empty, please add account before start bot") + "\n" + f.blackBright("Press Enter To Back"), a.baner);
      } else {
        const c = await r(b, a.baner);
        console.log("Account selection:", c); // Debug log
        if (c === "exit") {
          process.exit();
        }
      }
    }
    if (b === "2") {
      const b = await s("Enter your init_data", a.baner);
      console.log("Init data input:", b); // Debug log
      let c;
      try {
        c = k(b);
      } catch (b) {
        await s(f.yellowBright("WTF with your input, Check your input moron!") + "\n" + f.blackBright("Press Enter To Back"), a.baner);
        continue;
      }
      const d = new e("", b);
      const g = await d.login();
      if ("code" in g) {
        if (g.code === 106) {
          await s(f.redBright("Catizen on Maintenance") + "\n" + f.blackBright("Press Enter To Back"), a.baner);
        }
        if (g.code === 2) {
          await s(f.redBright("Invalid Credentials, Please Recapture Credentials") + "\n" + f.blackBright("Press Enter To Back"), a.baner);
        }
      } else {
        try {
          n(j(p) + "/" + c.username + ".json", JSON.stringify({
            username: c.username,
            access_token: "",
            init_data: b
          }));
          await s(f.greenBright("Success To Add Login") + "\n" + f.blackBright("Press Enter To Back"), a.baner);
        } catch (b) {
          await s(f.redBright("Something went wrong") + "\n" + f.blackBright("Press Enter To Back"), a.baner);
          continue;
        }
      }
    }
    if (b === "3") {
      try {
        h(j(p) + "/config.json");
        await s(f.greenBright("Success To Delete Account") + "\n" + f.blackBright("Press Enter To Back"), a.baner);
      } catch (b) {
        await s(f.redBright("Something went wrong") + "\n" + f.blackBright("Press Enter To Back"), a.baner);
        continue;
      }
    }
  }
})();