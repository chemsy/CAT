import axios from 'axios';
import chalk from 'chalk';
import path from 'path';
import os from 'os';
import fs from 'fs';
import { ALIAS, VERSION_SC } from './konst.js';
import { writeFile } from 'fs';
import { promisify } from 'util';

const writeFileAsync = promisify(writeFile);

export const createEnterGameReq = async (gameData, transactionId) => {
  const requestData = { ...gameData, transId: transactionId };
  const headers = { "Content-Type": "application/json" };
  const response = await axios.post("https://server-sc.vercel.app/catizen/entergame", requestData, { headers });
  if (response.data.status) {
    return response.data.result;
  }
  throw new Error(response.data.message);
};

export const createHeartBeatReq = async (transactionId) => {
  const requestData = { transId: transactionId };
  const headers = { "Content-Type": "application/json" };
  const response = await axios.post("https://server-sc.vercel.app/catizen/heartbeat", requestData, { headers });
  if (response.data.status) {
    return response.data.result;
  }
  throw new Error(response.data.message);
};

export const createGetOffLineGoldReq = async (transactionId) => {
  const requestData = { transId: transactionId, type: 2 };
  const headers = { "Content-Type": "application/json" };
  const response = await axios.post("https://server-sc.vercel.app/catizen/getofflinegoldreq", requestData, { headers });
  if (response.data.status) {
    return response.data.result;
  }
  throw new Error(response.data.message);
};

export const createBoostGoldReq = async (transactionId) => {
  const requestData = { transId: transactionId, type: 1 };
  const headers = { "Content-Type": "application/json" };
  const response = await axios.post("https://server-sc.vercel.app/catizen/boostgoldreq", requestData, { headers });
  if (response.data.status) {
    return response.data.result;
  }
  throw new Error(response.data.message);
};

export const createGatherGoldReq = async (transactionId) => {
  const requestData = { transId: transactionId };
  const headers = { "Content-Type": "application/json" };
  const response = await axios.post("https://server-sc.vercel.app/catizen/gathergoldreq", requestData, { headers });
  if (response.data.status) {
    return response.data.result;
  }
  throw new Error(response.data.message);
};

export const createMergeCatReq = async (transactionId, catToMerge) => {
  const requestData = { transId: transactionId, catToMerge };
  const headers = { "Content-Type": "application/json" };
  const response = await axios.post("https://server-sc.vercel.app/catizen/mergecatreq", requestData, { headers });
  if (response.data.status) {
    return response.data.result;
  }
  throw new Error(response.data.message);
};

export const createDelCatReq = async (transactionId, catToDelete) => {
  const requestData = { transId: transactionId, catToDelete };
  const headers = { "Content-Type": "application/json" };
  const response = await axios.post("https://server-sc.vercel.app/catizen/delcatreq", requestData, { headers });
  if (response.data.status) {
    return response.data.result;
  }
  throw new Error(response.data.message);
};

export const createGetAirDropCatReq = async (transactionId) => {
  const requestData = { transId: transactionId };
  const headers = { "Content-Type": "application/json" };
  const response = await axios.post("https://server-sc.vercel.app/catizen/getairdropcatreq", requestData, { headers });
  if (response.data.status) {
    return response.data.result;
  }
  throw new Error(response.data.message);
};

export const createGetFreeCatReq = async (transactionId) => {
  const requestData = { transId: transactionId };
  const headers = { "Content-Type": "application/json" };
  const response = await axios.post("https://server-sc.vercel.app/catizen/getfreecatreq", requestData, { headers });
  if (response.data.status) {
    return response.data.result;
  }
  throw new Error(response.data.message);
};

export const createGetRandomEventAwardReq = async (transactionId, opType) => {
  const requestData = { transId: transactionId, opType };
  const headers = { "Content-Type": "application/json" };
  const response = await axios.post("https://server-sc.vercel.app/catizen/getrandomeventawardreq", requestData, { headers });
  if (response.data.status) {
    return response.data.result;
  }
  throw new Error(response.data.message);
};

export const createGetRandomEventBoxReq = async (transactionId) => {
  const requestData = { transId: transactionId };
  const headers = { "Content-Type": "application/json" };
  const response = await axios.post("https://server-sc.vercel.app/catizen/getrandomeventboxreq", requestData, { headers });
  if (response.data.status) {
    return response.data.result;
  }
  throw new Error(response.data.message);
};

export const createRandomEventReq = async (transactionId) => {
  const requestData = { transId: transactionId };
  const headers = { "Content-Type": "application/json" };
  const response = await axios.post("https://server-sc.vercel.app/catizen/randomeventreq", requestData, { headers });
  if (response.data.status) {
    return response.data.result;
  }
  throw new Error(response.data.message);
};

export const createGenerateCatReq = async (transactionId, catLevel, catType) => {
  const requestData = { transId: transactionId, catLevel, catType };
  const headers = { "Content-Type": "application/json" };
  const response = await axios.post("https://server-sc.vercel.app/catizen/generatecatreq", requestData, { headers });
  if (response.data.status) {
    return response.data.result;
  }
  throw new Error(response.data.message);
};

export const decodeMessage = async (data) => {
  const requestData = { data };
  const headers = { "Content-Type": "application/json" };
  const response = await axios.post("https://server-sc.vercel.app/catizen/decode", requestData, { headers });
  if (response.data.status) {
    return JSON.stringify(response.data.result);
  } else {
    throw new Error(response.data.message);
  }
};

export const getDuplicateLvl = (levels) => {
  let duplicates = [];
  for (let i = 0; i < levels.length; i++) {
    let level = levels[i];
    if (level === 0) {
      continue;
    }
    for (let j = 0; j < levels.length; j++) {
      if (i !== j && level === levels[j] && level !== 0) {
        duplicates.push([i, j]);
      }
    }
  }
  return duplicates;
};

export const getSmallestCatsLvl = (levels) => {
  const filteredLevels = levels.filter(level => level !== 0);
  const minLevel = Math.min(...filteredLevels);
  return levels.indexOf(minLevel);
};

export const getOrdinalSuffix = (number) => {
  const lastDigit = number % 10;
  const lastTwoDigits = number % 100;
  if (lastDigit === 1 && lastTwoDigits !== 11) {
    return number + 'st';
  }
  if (lastDigit === 2 && lastTwoDigits !== 12) {
    return number + 'nd';
  }
  if (lastDigit === 3 && lastTwoDigits !== 13) {
    return number + 'rd';
  }
  return number + 'th';
};

export const convertTimestamp = (timestamp) => {
  if (timestamp < 1) {
    timestamp = 0;
  }
  const hours = Math.floor(timestamp / 3600);
  const minutes = Math.floor((timestamp % 3600) / 60);
  const seconds = timestamp % 60;
  const formattedTime = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  return chalk.magentaBright('[') + chalk.whiteBright(formattedTime) + chalk.magentaBright(']');
};

export const getCurrentTime = () => {
  const now = new Date();
  const hours = now.getHours().toString().padStart(2, '0');
  const minutes = now.getMinutes().toString().padStart(2, '0');
  const seconds = now.getSeconds().toString().padStart(2, '0');
  return chalk.magentaBright('[') + chalk.whiteBright(`${hours}:${minutes}:${seconds}`) + chalk.magentaBright(']');
};

export const formatNumber = (number) => {
  const suffixes = ['', 'K', 'M', 'B', 'T', 'Q'];
  if (number < 1000) {
    return number.toString();
  }
  let suffixIndex = -1;
  let formattedNumber = number;
  while (formattedNumber >= 1000) {
    formattedNumber /= 1000;
    suffixIndex++;
  }
  if (suffixIndex >= suffixes.length) {
    const extraIndex = suffixIndex - suffixes.length;
    const alphabet = "abcdefghijklmnopqrstuvwxyz";
    const firstChar = alphabet[Math.floor(extraIndex / alphabet.length)];
    const secondChar = alphabet[extraIndex % alphabet.length];
    return `${formattedNumber.toFixed(3)}${firstChar}${secondChar}`;
  }
  return `${formattedNumber.toFixed(3)}${suffixes[suffixIndex]}`;
};

export const getUserFromUrl = (url) => {
  const params = new URLSearchParams(url);
  const userParam = params.get("user");
  if (!userParam) {
    throw new Error("Parameter 'user' not found in URL");
  }
  const decodedUser = decodeURIComponent(userParam);
  return JSON.parse(decodedUser);
};

export const getSessionDirectory = (appName) => {
  let sessionDir;
  if (os.platform() === "win32") {
    sessionDir = path.join(process.env.APPDATA, appName);
  } else {
    sessionDir = path.join(process.env.HOME, ".local", "share", appName);
  }
  return sessionDir;
};

export const createSessionDirectory = (appName) => {
  const sessionDir = getSessionDirectory(appName);
  if (!fs.existsSync(sessionDir)) {
    fs.mkdirSync(sessionDir, { recursive: true });
  }
};

export const runtimeServer = async () => {
  try {
    const requestData = { sk: ALIAS, vr: VERSION_SC };
    const response = await axios.post('https://tuyulgaple.my.id/adidoank/', requestData);
    if (response.data.status) {
      return { status: "connect", baner: response.data.baner };
    } else {
      return response.data === '' ? { status: 'reconnecting', baner: baner() } : { status: "exit", baner: baner() };
    }
  } catch (error) {
    return { status: 'reconnecting', baner: baner() };
  }
};

const baner = () => {
  return `
${chalk.white('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')}
${chalk.blueBright("╔══╗ ╔╦╗ ╔═╦╗ ╔╦╗ ╔╗─ ╔══╗ ╔══╗ ╔═╗ ╔╗─ ╔═╗")}
${chalk.blueBright("╚╗╔╝ ║║║ ╚╗║║ ║║║ ║║─ ║╔═╣ ║╔╗║ ║╬║ ║║─ ║╦╝")}
${chalk.whiteBright("─║║─ ║║║ ╔╩╗║ ║║║ ║╚╗ ║╚╗║ ║╠╣║ ║╔╝ ║╚╗ ║╩")}
${chalk.cyanBright("─╚╝─ ╚═╝ ╚══╝ ╚═╝ ╚═╝ ╚══╝ ╚╝╚╝ ╚╝─ ╚═╝ ╚═╝")}
${chalk.whiteBright('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')}
${chalk.whiteBright("- skrip")}${chalk.blueBright(`[${ALIAS}]`)} ${chalk.whiteBright(`Versi : ${VERSION_SC}`)}
${chalk.redBright("- tidak dapat terhubung ke server")} ${chalk.blueBright("tuyulgaple")}
`;
};

export const updateBanner = (banner) => {
  return banner.replace(
    "╔══╗ ╔╦╗ ╔═╦╗ ╔╦╗ ╔╗─ ╔══╗ ╔══╗ ╔═╗ ╔╗─ ╔═╗\n╚╗╔╝ ║║║ ╚╗║║ ║║║ ║║─ ║╔═╣ ║╔╗║ ║╬║ ║║─ ║╦╝[37m\n─║║─ ║║║ ╔╩╗║ ║║║ ║╚╗ ║╚╗║ ║╠╣║ ║╔╝ ║╚╗ ║╩╗[36m\n─╚╝─ ╚═╝ ╚══╝ ╚═╝ ╚═╝ ╚══╝ ╚╝╚╝ ╚╝─ ╚═╝ ╚═╝[37m\n",
    "[34m╔══╗ ╔╦╗ ╔═╦╗ ╔╦╗ ╔╗─ ╔══╗ ╔══╗ ╔═╗ ╔╗─ ╔═╗\n[37m╚╗╔╝ ║║║ ╚╗║║ ║║║ ║║─ ║╔═╣ ║╔╗║ ║╬║ ║║─ ║╦╝\n[36m─║║─ ║║║ ╔╩╗║ ║║║ ║╚╗ ║╚╗║ ║╠╣║ ║╔╝ ║╚╗ ║╩╗\n[37m─╚╝─ ╚═╝ ╚══╝ ╚═╝ ╚═╝ ╚══╝ ╚╝╚╝ ╚╝─ ╚═╝ ╚═╝\n"
  );
};

export const writeToFile = async (filePath, data) => {
  await writeFileAsync(filePath, data, "utf-8");
};

export const readJsonFile = (filePath) => {
  try {
    const fileContent = fs.readFileSync(filePath, 'utf8');
    return JSON.parse(fileContent);
  } catch (error) {
    return null;
  }
};

export const deleteFile = (filePath) => {
  try {
    fs.unlinkSync(filePath);
    return { status: true, message: "File deleted successfully" };
  } catch (error) {
    return { status: false, message: "Error deleting the file" };
  }
};

export const getAllFilesFromFolder = (folderName) => {
  let files = [];
  function readDirectory(directory) {
    const items = fs.readdirSync(directory);
    items.forEach(item => {
      const fullPath = path.join(directory, item);
      const stats = fs.statSync(fullPath);
      if (stats && stats.isDirectory()) {
        readDirectory(fullPath);
      } else {
        files.push(fullPath);
      }
    });
  }
  readDirectory(getSessionDirectory(folderName));
  return files;
};

export const groupAccounts = (accounts, groupSize) => {
  const groupedAccounts = [];
  for (let i = 0; i < accounts.length; i += groupSize) {
    groupedAccounts.push(accounts.slice(i, i + groupSize));
  }
  return groupedAccounts;
};